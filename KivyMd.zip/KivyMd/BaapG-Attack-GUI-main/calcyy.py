from kivymd.app import *
from kivymd.uix.label import *
from kivy.uix.image import *
from kivy.uix.screenmanager import *
from kivy.lang import Builder
from kivy.core.text import LabelBase 
from kivymd.uix.button import *
from kivymd.uix.screen import *
from kivymd.uix.textfield import *
from kivy.core.audio import *
from kivymd.uix.list import *
from kivymd.toast import *
from kivy.uix.scrollview import *
import requests
import webbrowser
import os
import os
import subprocess
import sys
import threading
from pathlib import Path
from kivy.clock import Clock
from functools import partial
from kivymd.icon_definitions import md_icons
from kivy.utils import platform
from kivy.core.window import Window
import time
import _thread


screen_manager = ScreenManager()
if platform != "android":
	Window.size = (540,960)
def makeFile(data,name):
	if os.path.exists(name):
		return True
	else:
		pass
	with open(name, "wb") as binary_file:
		binary_file.write(data)
		binary_file.close()
	return True

def isint(text):
	try:
		int(text)
	except Exception:
		return False
	return True
	
calcy_str='''
ScreenManager:
    Start:
    Hello:
    

<Start>:
    name: 'start'
    MDFloatLayout:
		md_bg_color: 0,0,0,1
        Image:
            source: 'gnlogo.png'
            pos_hint : {"center_x":0.5,"center_y":0.65}
			size_hint_y: 0.65
			size_hint_x: 0.65

        MDLabel:
            text: 'from'
            font_type: 'Caption'
            font_size: '14sp'
            halign: 'center'
            color: 1,1,1,1
            pos_hint : {"center_x":0.5,"center_y":0.15}
        
        Image:
            source: 'assets/nlogo.jpg'
            pos_hint : {"center_x":0.5,"center_y":0.10}
			size_hint_y: 0.45
			size_hint_x: 0.45


'''

class Start(Screen):
    pass
class Hello(Screen):
    pass
class Donation(Screen):
    pass
class Permision(Screen):
    pass
class Success(Screen):
    pass


sm = ScreenManager()
sm.add_widget(Start(name = 'start'))
sm.add_widget(Hello(name = 'hello'))
sm.add_widget(Donation(name = 'donation'))
sm.add_widget(Permision(name = 'permision'))
sm.add_widget(Success(name = 'success'))


class DemoApp(MDApp):
    
    def build(self):
        screen = Screen()

        self.help_str = Builder.load_string(calcy_str)

        screen.add_widget(self.help_str)
        return screen