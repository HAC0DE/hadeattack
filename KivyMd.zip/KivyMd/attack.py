from kivymd.app import *
from kivymd.uix.label import *
from kivy.uix.image import Image
from kivy.uix.widget import Widget
from kivy.uix.image import *
from kivy.uix.screenmanager import *
from kivy.lang import Builder
from kivy.core.text import LabelBase 
from kivymd.uix.button import *
from kivymd.uix.screen import *
from kivymd.uix.textfield import *
from kivy.core.audio import *
from kivymd.uix.list import *
from kivymd.toast import *
from kivy.uix.scrollview import *
import requests
import webbrowser
import os
import os
import subprocess
import sys
import threading
from pathlib import Path
from kivy.clock import Clock
from functools import partial
from kivymd.icon_definitions import md_icons
from kivy.utils import platform
from kivy.core.window import Window
import time
import _thread
from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import Screen,ScreenManager
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from kivy.storage.jsonstore import JsonStore
from kivymd.uix.picker import MDDatePicker
from kivy.lang import Builder
from kivymd.uix.picker import MDDatePicker
from kivymd.uix.button import MDFlatButton,MDIconButton,MDRectangleFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.app import MDApp

from kivymd.uix.snackbar import Snackbar

from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, Screen

from kivymd.uix.taptargetview import MDTapTargetView


screen_manager = ScreenManager()

helper_string = '''
ScreenManager:
    Start:
    #Home:
        
<Start>:
    name: 'start'
    MDFloatLayout:
		md_bg_color: 0,0,0,1

		MDLabel:
			text : "EULA"	
			hlaign : "Center"
			pos_hint : {"center_x":0.75,"center_y":0.9}
			font_size : "35sp"
			#font_name : "assets/Poppins-Regular.ttf"

		Image:
			source :"assets/logo.png"
			pos_hint :  {"center_x":0.5,"center_y":0.65}
			size_hint_y: 0.45
			size_hint_x: 0.45

<Home>:
    name: 'home'





'''



class Start(Screen):
    pass
class Home(Screen):
    pass

sm = ScreenManager()
sm.add_widget(Start(name = 'start'))
sm.add_widget(Home(name = 'home'))

class DemoApp(MDApp):
    def build(self):
        screen = Screen()
        self.help_str = Builder.load_string(helper_string)
        screen.add_widget(self.help_str)
        return screen





DemoApp().run()










